self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d37b88f31ad8815bf54e3187df65d060",
    "url": "/area_under_curve/index.html"
  },
  {
    "revision": "36c67e72efc1c5422b73",
    "url": "/area_under_curve/static/css/main.f7575985.chunk.css"
  },
  {
    "revision": "2ce2c06bacbf8e687f14",
    "url": "/area_under_curve/static/js/2.fdfe3d40.chunk.js"
  },
  {
    "revision": "99bd0487192ec9e7d9ee8fbbd91ee444",
    "url": "/area_under_curve/static/js/2.fdfe3d40.chunk.js.LICENSE.txt"
  },
  {
    "revision": "36c67e72efc1c5422b73",
    "url": "/area_under_curve/static/js/main.aaa015a9.chunk.js"
  },
  {
    "revision": "e11756c6211bf5f1b9ac",
    "url": "/area_under_curve/static/js/runtime-main.b071b0fa.js"
  }
]);